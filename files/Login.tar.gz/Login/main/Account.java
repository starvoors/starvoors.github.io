package main;

public class Account {
     private int amount;
     public int id;
     private static int count = 1; //Used to generate unique id numbers.
     
     Account() {
        amount = 100;
        id = count;
        count++;
     }
          
     public int getAmount() {
        return amount;
     }
     
     public void deposit (int money) {
        if (money >= 0)
           amount += money;
     }
      
     public void withdraw(int money) {
        if (money >= 0)
           amount -= money;
     }
         
     public Account transfer(int money, Account receiver) {
        if (money >= 0) {
           withdraw(money); 
           receiver.deposit(money);
         }
         return receiver;
     }
}
