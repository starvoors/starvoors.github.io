package main;

public class SystemCentral {

    public static HashTable users = new HashTable (2);
    
}
