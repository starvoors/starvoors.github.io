package main;

public class User {
    
    private int id;
    private String userName;
    private String name;
    private String surname;
    public Account account;

    public int getID () {
        return id;		
    }

    public String getUserName (){
        return userName;
    }

    public String getName (){
        return name;
    }

    public String getSurname () {
        return surname;
    }

    public Account getAccount() {
         return account;
    }

    User (String userName, String name, String surname, int id) {
        this.id = id;
        this.userName = userName;
        this.name = name;
        this.surname = surname;
        this.account = new Account();
    }	

    public String toString(){
        return userName;
    }
}
