package main;

public final class DataBase {
	
    private static int capacity = 3;

    static User Checho = new User("checho","Mauricio", "Chimento", 1);
    static User Wolfgang = new User("supervisor","Wolfgang", "Ahrendt", 3);
    static User Gerardo = new User("cosupervisor", "Gerardo", "Schneider", 4); 
    
    static User[] db = {Checho, Wolfgang, Gerardo};
    
    private DataBase () {}
	
    public static User search(String userName, int password) {
        User u = null;
        int i = 0;

        while (i < capacity){			
            if (db[i].getUserName().equals(userName) && (db[i].getID() == password)) {
               u = db[i];
               break;
            } else {
                 i++;
              }
        }
        return u;
    }
}
