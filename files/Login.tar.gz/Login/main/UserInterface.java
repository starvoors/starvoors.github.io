package main;

public class UserInterface {
		
    private String name;
    public User u;

    public User getUser() {return u;}

    UserInterface(String str){
        name = str;     
        u = null;
    }	
	
    public void login (String userName, int password) {
        User u = DataBase.search(userName, password);

        if (u != null) {
           if ((SystemCentral.users.contains(u, password) < 0)) {	
              SystemCentral.users.add(u, password);

              if ((SystemCentral.users.contains(u, password) >= 0)) {	    			       
                  this.u = u;	            	                               
                  //System.out.printf("The user " + u.getName() + " " + u.getSurname() + " is logged.\n");
              } else {
                  //System.out.printf("Sorry, the system is at its full capacity. Try to loggin later.\n");
                }	            	    
           } else {   	
                //System.out.printf("The user is already logged.\n");
             }
        } else {    
            //System.out.printf("Wrong user name and/or password.\n");
          }
    }

    public void logout () {
        if (u != null){
           SystemCentral.users.delete(u, u.getID());
           u = null;
        }
    }

    public void inactivity(){
        if (u != null){
           //System.out.println("\nUser was logged out due to inactivity!");	
           SystemCentral.users.delete(u, u.getID());
           u = null;
           //System.out.println("\nChoose an action to perform:");
        }
    }

    public void deposit(int money){
        if (u != null)
           if (money >= 0)		   
              u.getAccount().deposit(money);
    }
	
    public void withdraw(int money){
        if (u != null)
           if (money >= 0){			   
              if (u.getAccount().getAmount() - money >= 0) {
                 u.getAccount().withdraw(money);
              } else {
                  //System.out.printf("\nNot enough money into the account to perform the operation."); 
                }			   
           }
    }
}
