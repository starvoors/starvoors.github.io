package java.io;

/**
 * @generated
 */
public interface Closeable extends java.lang.AutoCloseable {
}