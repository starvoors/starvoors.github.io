package java.io;

/**
 * @generated
 */
public interface Serializable {
}