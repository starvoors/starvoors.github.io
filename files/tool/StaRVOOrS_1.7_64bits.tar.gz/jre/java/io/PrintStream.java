package java.io;

/**
 * @generated
 */
public class PrintStream extends java.io.FilterOutputStream implements java.lang.Appendable, java.io.Closeable {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public void println(java.lang.String param0);
}