package java.lang;

/**
 * @generated
 */
public interface Runnable {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public abstract void run();
}