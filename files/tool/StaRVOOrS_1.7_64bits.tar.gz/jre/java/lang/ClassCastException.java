package java.lang;

/**
 * @generated
 */
public class ClassCastException extends java.lang.RuntimeException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public ClassCastException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public ClassCastException(java.lang.String param0);
}