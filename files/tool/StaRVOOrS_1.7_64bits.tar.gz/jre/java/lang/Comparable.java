package java.lang;

/**
 * @generated
 */
public interface Comparable {
}