package java.lang;

/**
 * @generated
 */
public final class Class extends java.lang.Object implements java.io.Serializable, java.lang.reflect.GenericDeclaration, java.lang.reflect.Type, java.lang.reflect.AnnotatedElement {
   /**
    * @generated
    */
   /*@ private behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   private Class();
}