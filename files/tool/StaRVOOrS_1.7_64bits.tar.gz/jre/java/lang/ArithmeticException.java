package java.lang;

/**
 * @generated
 */
public class ArithmeticException extends java.lang.RuntimeException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public ArithmeticException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public ArithmeticException(java.lang.String param0);
}