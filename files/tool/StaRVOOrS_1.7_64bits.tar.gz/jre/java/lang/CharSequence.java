package java.lang;

/**
 * @generated
 */
public interface CharSequence {
}