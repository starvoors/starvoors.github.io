package java.lang;

/**
 * @generated
 */
public interface Iterable {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public abstract java.util.Iterator iterator();
}