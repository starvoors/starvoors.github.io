package java.lang;

/**
 * @generated
 */
public class ArrayIndexOutOfBoundsException extends java.lang.IndexOutOfBoundsException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public ArrayIndexOutOfBoundsException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public ArrayIndexOutOfBoundsException(int param0);

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public ArrayIndexOutOfBoundsException(java.lang.String param0);
}