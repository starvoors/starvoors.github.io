package java.lang.reflect;

/**
 * @generated
 */
public interface Type {
}