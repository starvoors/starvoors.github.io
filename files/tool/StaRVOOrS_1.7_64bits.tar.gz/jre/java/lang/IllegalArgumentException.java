package java.lang;

/**
 * @generated
 */
public class IllegalArgumentException extends java.lang.RuntimeException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public IllegalArgumentException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public IllegalArgumentException(java.lang.String param0);
}