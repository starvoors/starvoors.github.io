package java.lang;

/**
 * @generated
 */
public class OutOfMemoryError extends java.lang.VirtualMachineError {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public OutOfMemoryError();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public OutOfMemoryError(java.lang.String param0);
}