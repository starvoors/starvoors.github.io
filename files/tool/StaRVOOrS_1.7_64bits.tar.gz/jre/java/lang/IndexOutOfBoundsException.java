package java.lang;

/**
 * @generated
 */
public class IndexOutOfBoundsException extends java.lang.RuntimeException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public IndexOutOfBoundsException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public IndexOutOfBoundsException(java.lang.String param0);
}