package java.lang;

/**
 * @generated
 */
abstract class AbstractStringBuilder extends java.lang.Object implements java.lang.Appendable, java.lang.CharSequence {
}