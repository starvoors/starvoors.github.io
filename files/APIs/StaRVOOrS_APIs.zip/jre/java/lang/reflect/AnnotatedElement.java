package java.lang.reflect;

/**
 * @generated
 */
public interface AnnotatedElement {
}