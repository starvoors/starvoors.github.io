package java.lang.reflect;

/**
 * @generated
 */
public interface GenericDeclaration {
}