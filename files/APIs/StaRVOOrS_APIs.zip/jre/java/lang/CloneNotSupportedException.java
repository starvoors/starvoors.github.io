package java.lang;

/**
 * @generated
 */
public class CloneNotSupportedException extends java.lang.Exception {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public CloneNotSupportedException();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public CloneNotSupportedException(java.lang.String param0);
}