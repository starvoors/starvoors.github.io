package java.lang;

/**
 * @generated
 */
public class IllegalStateException extends java.lang.RuntimeException {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public IllegalStateException();
}