package java.lang;

/**
 * @generated
 */
public class NoClassDefFoundError extends java.lang.LinkageError {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public NoClassDefFoundError();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public NoClassDefFoundError(java.lang.String param0);
}