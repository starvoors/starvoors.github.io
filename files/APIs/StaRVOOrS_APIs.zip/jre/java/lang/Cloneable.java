package java.lang;

/**
 * @generated
 */
public interface Cloneable {
}