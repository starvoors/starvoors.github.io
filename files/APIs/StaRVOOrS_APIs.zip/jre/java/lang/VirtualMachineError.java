package java.lang;

/**
 * @generated
 */
public abstract class VirtualMachineError extends java.lang.Error {
   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public VirtualMachineError();

   /**
    * @generated
    */
   /*@ public behavior
     @ requires true;
     @ ensures true;
     @ assignable \everything;
     @*/
   public VirtualMachineError(java.lang.String param0);
}