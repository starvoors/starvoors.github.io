package java.io;

/**
 * @generated
 */
public class FilterOutputStream extends java.io.OutputStream {
}