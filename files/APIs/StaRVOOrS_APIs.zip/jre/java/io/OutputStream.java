package java.io;

/**
 * @generated
 */
public abstract class OutputStream extends java.lang.Object implements java.io.Closeable, java.io.Flushable {
}