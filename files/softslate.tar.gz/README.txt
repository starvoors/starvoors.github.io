When this case study was developed, there was not an open source version of SoftSlate available online. Therefore, we do not have permission to make the verified sources publicly available.
